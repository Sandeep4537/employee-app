import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { user } from './user';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {


  addEmpUrl : string;
  getEmpUrl : string;
  updateEmpUrl : string;
  deleteEmpUrl : string;
  login:string;

  constructor(private http : HttpClient) {

    this.addEmpUrl = "http://localhost:9091/emp/addEmployee";
    this.getEmpUrl = "http://localhost:9091/emp/getAllEmployee";
    this.updateEmpUrl = "http://localhost:9091/emp/updateEmployee";
    this.deleteEmpUrl = "http://localhost:9091/emp/deleteEmployeeByID"
    this.login = "http://localhost:9091/emp/successlogin"
   }

checkuser(e:user):Observable<user>
{
  return this.http.get<user>(this.login)
}

   addEmployee(emp : Employee) : Observable<Employee>{
      return this.http.post<Employee>(this.addEmpUrl, emp)

   }

   getAllEmployee(): Observable<any>{
    return this.http.get<any>(this.getEmpUrl);

   }

   updateEmployee(emp : Employee):Observable<Employee>{
    return this.http.put<Employee>(this.updateEmpUrl+'/'+emp.id, emp);
   }

  deleteEmployee(emp : Employee) : Observable<Employee>{
    return this.http.delete<Employee>(this.deleteEmpUrl+'/'+emp.id);
  }
}
