export class user
 {
id?:number;
user_name?:string;
active?:boolean;
password?:string;
roles?:string;
 }
