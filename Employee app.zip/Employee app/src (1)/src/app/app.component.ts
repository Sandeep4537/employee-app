import { Component } from '@angular/core';
import { EmployeeService } from './employee.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

username?:string;
password?:string;

obj={}

constructor(private serv:EmployeeService,private route:Router){}
res:any

checkuser()
{
  this.obj={username:this.username,password:this.password}
  this.serv.checkuser(this.obj).subscribe(
    res=>
    {console.log(res)
  this.res=res
        if(res)
            this.route.navigate(['/emp'])

},
  err=>console.log(err))

}



}

