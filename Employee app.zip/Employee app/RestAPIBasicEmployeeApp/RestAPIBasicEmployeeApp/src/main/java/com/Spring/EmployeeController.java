package com.Spring;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;


// controller endpoints get called in angular application
// for this , cross origin must be allowed

// angular appliucation can access end points from this controller class
// only when @CrossOrigin annotaion is used



@RestController
@CrossOrigin(origins = "*") 
public class EmployeeController {
		
	@Autowired
	private EmployeeService employeeService;
	
	boolean login=false;
	
	@GetMapping("/")
	public String home()
	{
		return "home";
	}
	
	
	@GetMapping("/logout")
	public String logout()
	{
		return "logout";
	}
	
	@RequestMapping(value="/successlogin", method=RequestMethod.GET)	
    public boolean successlogin() {			
        return true;
    }

    
	
	
	//Add new employee
	@PostMapping("addEmployee")  // saving the record
	@CrossOrigin(origins = "http://localhost:4200")
	public Employee addEmployee(@RequestBody Employee employee) {
		System.out.println(employee);
		return employeeService.addEmployee(employee);
	}
	// @RequestBody denotes the new json records 
	
	
	
	//https://localhost:8080/folder1/folder2?var1=music&var2=daljeet&var3=goodsong
	// passing the variables(query string) with value within URL
	//var1,var2,var3 are Request Parameters
	
	
	
	
	//Get All employees
	/*@GetMapping("getAllEmployees")  // fetching the record	
	public Page<Employee> getAllEmployees(@RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "5") int size) 
	{
		return employeeService.getAllEmployees(page,size);
	}*/
	
	
	//Get All employees
	@GetMapping("getAllEmployee")  // fetching the record
	@CrossOrigin(origins = "http://localhost:4200")
	public List<Employee> getAllEmployee() 
	{
		return employeeService.getAllEmployee();
	}
	
	
	
	//https://localhost:8080/emp/1110  so 1110 is the path variable
	//Get employee by Id
		@GetMapping("getEmployeeByID/{id}")
		@CrossOrigin(origins = "http://localhost:4200")
		public Employee getEmployeeById(@PathVariable int id) {
			return employeeService.getEmployeeById(id);
		}
	
	
		
    
		
		
		
		//Update employee
		@PutMapping("updateEmployee/{id}")  // updating the record
		@CrossOrigin(origins = "http://localhost:4200")
		public Employee updateEmployee(@RequestBody Employee employee, @PathVariable int id) {
			return employeeService.updateEmployee(employee,id);
		}
	
		
		
		
		
		//Delete employee by Id
		@DeleteMapping("deleteEmployeeByID/{id}")  
		@CrossOrigin(origins = "http://localhost:4200")
		public void deleteEmployeeById(@PathVariable("id") Integer id) {
			employeeService.deleteEmployeeById(id);
		}
		
		
		
				
}


