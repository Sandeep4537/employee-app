package com.Spring;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;


@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepository emprep;

	public Employee addEmployee(Employee employee) {
		return emprep.save(employee);
	}
	
	
	
	public Page<Employee> getAllEmployees(int pg ,int s)
	{
		return emprep.findAll(PageRequest.of(pg,s));  
	}
	
	
	public List<Employee> getAllEmployee()
	{
		return emprep.findAll();  
	}
	

	
	
	public Employee getEmployeeById(int id) {
		return emprep.findById(id).orElse(null);
		
		
	}
	
	

	public Employee updateEmployee(Employee employee, int id) {
		Employee existingEmp = emprep.findById(id).get();
		
		existingEmp.setName(employee.getName());
		existingEmp.setEmail(employee.getEmail());
		existingEmp.setSalary(employee.getSalary());
		
		return emprep.saveAndFlush(employee);

		
	}

	public void deleteEmployeeById(Integer id) {
		emprep.deleteById(id);
		
	}
}
